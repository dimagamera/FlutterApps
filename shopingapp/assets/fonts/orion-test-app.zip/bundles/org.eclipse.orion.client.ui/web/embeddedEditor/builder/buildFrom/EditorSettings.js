/*eslint-env browser, amd*/
define([], function(){
	return null;
});