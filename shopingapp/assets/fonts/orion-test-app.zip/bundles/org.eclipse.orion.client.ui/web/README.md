Orion Release Notes for R4.0
============================

Orion 4.0 is to be released at the end of October, 2013 in concert with the EclipseCon Europe.  These notes are to record any anomolies which a user might encounter that could impact behaviour but have a workaround or expected outcome.

* A search on Orion has a limitation of "Whole word" option for DBCS characters [Bug 407258](https://bugs.eclipse.org/bugs/show_bug.cgi?id=407258 "Bug 407258"). This bug is based on a limitation of JavaScript that is not Unicode-aware.
