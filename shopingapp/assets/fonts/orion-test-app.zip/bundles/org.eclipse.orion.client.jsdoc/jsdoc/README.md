Empty directory required for build
